<?php

namespace Illuminate\Contracts\Filesystem;

use Exception;

class FileExistsException extends Exception
{
    //
}
